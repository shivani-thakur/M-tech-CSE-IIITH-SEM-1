var img1 = {
  ansCoords: [  // right answer LOCUS
    [83, 159],  // [x, y] zeroed coordinates
    [72, 292],
    [65, 513],
    [418, 103],
    [484, 372]
  ],
  ansArea: [  // right answer AREA
    [15, 20], // [x-radius, y-radius]
    [20, 30],
    [25, 20],
    [20, 20],
    [20, 45]
  ],
  cssClass: 'img1',
  found: [] // will receive arrays of found areas from logFound()
};
var img2 = {
  ansCoords: [  // right answer LOCUS
    [28, 207],  // [x, y] zeroed coordinates
    [139, 504],
    [267, 348],
    [312, 224],
    [477, 455]
  ],
  ansArea: [  // right answer AREA
    [185, 190], // [x-radius, y-radius]
    [75, 55],
    [40, 40],
    [30, 65],
    [70, 85]
  ],
  cssClass: 'img2',
  found: [] // will receive arrays of found areas from logFound()
};
