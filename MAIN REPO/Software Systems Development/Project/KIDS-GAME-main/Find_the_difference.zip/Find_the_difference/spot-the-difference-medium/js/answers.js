var img1 = {
  ansCoords: [  // right answer LOCUS
    [229, 207],  // [x, y] zeroed coordinates
    [262, 410],
    [378, 442],
    [69, 370],
    [39, 234]
  ],
  ansArea: [  // right answer AREA
    [10, 20], // [x-radius, y-radius]
    [20, 20],
    [15, 15],
    [65, 25],
    [20, 20]
  ],
  cssClass: 'img1',
  found: [] // will receive arrays of found areas from logFound()
};
var img2 = {
  ansCoords: [  // right answer LOCUS
    [262, 52],  // [x, y] zeroed coordinates
    [114, 248],
    [329, 463],
    [114, 496],
    [461, 446]
  ],
  ansArea: [  // right answer AREA
    [25, 40], // [x-radius, y-radius]
    [50, 40],
    [45, 110],
    [55, 55],
    [20, 30]
  ],
  cssClass: 'img2',
  found: [] // will receive arrays of found areas from logFound()
};
var img3 = {
  ansCoords: [  // right answer LOCUS
    [149, 67],  // [x, y] zeroed coordinates
    [388, 154],
    [116, 288],
    [461, 357],
    [179, 493]
  ],
  ansArea: [  // right answer AREA
    [50, 50], // [x-radius, y-radius]
    [20, 50],
    [20, 40],
    [20, 50],
    [10, 20]
  ],
  cssClass: 'img3',
  found: [] // will receive arrays of found areas from logFound()
};
var img4 = {
  ansCoords: [  // right answer LOCUS
    [59, 76],  // [x, y] zeroed coordinates
    [438, 261],
    [304, 351],
    [237, 135],
    [102, 517]
  ],
  ansArea: [  // right answer AREA
    [40, 75], // [x-radius, y-radius]
    [40, 30],
    [80, 50],
    [45, 45],
    [15, 40]
  ],
  cssClass: 'img4',
  found: [] // will receive arrays of found areas from logFound()
};
var img5 = {
  ansCoords: [  // right answer LOCUS
    [232, 130],  // [x, y] zeroed coordinates
    [392, 251],
    [455, 167],
    [278, 469],
    [44, 430]
  ],
  ansArea: [  // right answer AREA
    [45, 45], // [x-radius, y-radius]
    [50, 25],
    [55, 40],
    [40, 75],
    [30, 60]
  ],
  cssClass: 'img5',
  found: [] // will receive arrays of found areas from logFound()
};

var img6 = {
  ansCoords: [  // right answer LOCUS
    [114, 212],  // [x, y] zeroed coordinates
    [434, 95],
    [449, 435],
    [385, 253],
    [226, 371]
  ],
  ansArea: [  // right answer AREA
    [65, 35], // [x-radius, y-radius]
    [12, 26],
    [15, 55],
    [30, 10],
    [20, 10]
  ],
  cssClass: 'img6',
  found: [] // will receive arrays of found areas from logFound()
};
var img7 = {
  ansCoords: [  // right answer LOCUS
    [209, 41],  // [x, y] zeroed coordinates
    [172, 420],
    [261, 317],
    [61, 477],
    [330, 152]
  ],
  ansArea: [  // right answer AREA
    [70, 40], // [x-radius, y-radius]
    [20, 50],
    [10, 10],
    [10, 20],
    [30, 40]
  ],
  cssClass: 'img7',
  found: [] // will receive arrays of found areas from logFound()
};
var img8 = {
  ansCoords: [  // right answer LOCUS
    [202, 188],  // [x, y] zeroed coordinates
    [416, 410],
    [229, 429],
    [65, 260],
    [245, 50]
  ],
  ansArea: [  // right answer AREA
    [20, 80], // [x-radius, y-radius]
    [90, 45],
    [35, 15],
    [30, 100],
    [70, 40]
  ],
  cssClass: 'img8',
  found: [] // will receive arrays of found areas from logFound()
};
var img9 = {
  ansCoords: [  // right answer LOCUS
    [134, 304],  // [x, y] zeroed coordinates
    [410, 336],
    [377, 172],
    [64, 498],
    [165, 155]
  ],
  ansArea: [  // right answer AREA
    [20, 30], // [x-radius, y-radius]
    [100, 50],
    [60, 80],
    [80, 40],
    [25, 50]
  ],
  cssClass: 'img9',
  found: [] // will receive arrays of found areas from logFound()
};
var img10 = {
  ansCoords: [  // right answer LOCUS
    [452, 427],  // [x, y] zeroed coordinates
    [304, 303],
    [213, 193],
    [419, 285],
    [58, 388]
  ],
  ansArea: [  // right answer AREA
    [40, 30], // [x-radius, y-radius]
    [50, 80],
    [30, 30],
    [40, 35],
    [40, 40]
  ],
  cssClass: 'img10',
  found: [] // will receive arrays of found areas from logFound()
};


