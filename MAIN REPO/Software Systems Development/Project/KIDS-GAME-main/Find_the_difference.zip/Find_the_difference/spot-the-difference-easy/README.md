# Spot the difference

A web version of the classic Spot the Difference arcade game. Demo [here](https://nickangtc.github.io/spot-the-difference/).

This was the first individual project I did as a student at General Assembly.

### v0.1 screenshot September 2016
![nickang game v0.1 screenshot](spot-the-difference.png)

### v0.2 gameplay November 2016

![nickang game v0.2 screenshot](http://i.giphy.com/3o7TKDTFUX3CPFdNqE.gif)

Note: Images used in this project are copyrighted by [Kat games](http://www.katgames.com/5spots/5spots.html).
