var img1 = {
  ansCoords: [  // right answer LOCUS
    [108, 127],  // [x, y] zeroed coordinates
    [134, 496],
    [160, 292],
    [259, 234],
    [361, 277]
  ],
  ansArea: [  // right answer AREA
    [80, 100], // [x-radius, y-radius]
    [55, 60],
    [40, 60],
    [45, 90],
    [45, 60]
  ],
  cssClass: 'img1',
  found: [] // will receive arrays of found areas from logFound()
};
var img2 = {
  ansCoords: [  // right answer LOCUS
    [186, 136],  // [x, y] zeroed coordinates
    [200, 319],
    [387, 167],
    [376, 363],
    [374, 318]
  ],
  ansArea: [  // right answer AREA
    [80, 70], // [x-radius, y-radius]
    [60, 55],
    [30, 45],
    [30, 25],
    [50, 10]
  ],
  cssClass: 'img2',
  found: [] // will receive arrays of found areas from logFound()
};
var img3 = {
  ansCoords: [  // right answer LOCUS
    [435, 56],  // [x, y] zeroed coordinates
    [290, 37],
    [419, 398],
    [306, 275],
    [178, 454]
  ],
  ansArea: [  // right answer AREA
    [25, 50], // [x-radius, y-radius]
    [15, 45],
    [60, 95],
    [35, 40],
    [95, 60]
  ],
  cssClass: 'img3',
  found: [] // will receive arrays of found areas from logFound()
};
var img4 = {
  ansCoords: [  // right answer LOCUS
    [349, 95],  // [x, y] zeroed coordinates
    [79, 192],
    [147, 410],
    [380, 430],
    [168, 156]
  ],
  ansArea: [  // right answer AREA
    [80, 80], // [x-radius, y-radius]
    [30, 140],
    [65, 120],
    [65, 50],
    [60, 60]
  ],
  cssClass: 'img4',
  found: [] // will receive arrays of found areas from logFound()
};
var img5 = {
  ansCoords: [  // right answer LOCUS
    [226, 175],  // [x, y] zeroed coordinates
    [137, 395],
    [194, 414],
    [372, 253],
    [184, 317]
  ],
  ansArea: [  // right answer AREA
    [25, 45], // [x-radius, y-radius]
    [60, 50],
    [50, 60],
    [65, 65],
    [100, 50]
  ],
  cssClass: 'img5',
  found: [] // will receive arrays of found areas from logFound()
};
