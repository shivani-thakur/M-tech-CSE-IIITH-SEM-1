## Overview
Design a login and sign up page
If user doesn't exist and tries to login show error
If existing user tries to signup show error
On successful login, go to to-do list page
All fields in to-do list are mandatory
If selected date is past date, show error

## To run:
** to run backend server:
- open server folder in terminal
- run command 'npm start'

** to run frontend server:
- open client folder in terminal
- run command 'npm start'

** to start db:
- open mongodb compass
- click on 'connect' button, follow the wizard

## Installations
- open server folder in terminal, run following commands
npm init
npm install express
npm install mongoose
npm install cors
npm install bcryptjs
npm install crypto
npm install jsonwebtoken