const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const app = express();
app.use(express.json());
app.use(cors());
require("./User");

// Generate a JWT token
const secretKey = crypto.randomBytes(32).toString('hex');

// Connect to local mongodb
const dbUrl = "mongodb://0.0.0.0:27017/Lab7";
mongoose.connect(dbUrl, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => {
    console.log("connected to the db");
}).catch((oError) => {
    console.log(oError);
});

// check if server started
app.listen(5000, () => {
    console.log("server started");
});

// get the users model
const usersModel = mongoose.model("User");

// make an api for signup
app.post("/signup", async (request, response) => {
    const {name, password} = request.body;
    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);
    try {
        const isExistingUser = await usersModel.findOne({name});
        if (isExistingUser) {
            return response.send({status: 400, error: oError, message: "Existing user. Please signin." });
        }
        await usersModel.create({
            name: name,
            password: hashedPassword
        });
        response.send({status: 200, message: "User created successfully." });
    } catch (oError) {
        console.log(oError);
        response.send({status: 400, error: oError, message: "Failed to signup. Please try again." });
    }
});

// make an api for login
app.post("/login", async (request, response) => {
    const {name, password} = request.body;
    const isExistingUser = await usersModel.findOne({name});
    if (!isExistingUser) {
        return response.send({status: 400, message: "User doesn't exists. Please signup." });
    }

    const isPasswordValid = await bcrypt.compare(password, isExistingUser.password);
    if (!isPasswordValid) {
        return response.send({status: 400, message: "Incorrect password" });
    }

    const token = jwt.sign({}, secretKey);
    const resData = {
        token: token,
    }
    if (response.status(201)) {
        return response.send({status: 200, data: resData, message: "Login successful" });
    } else {
        response.send({status: 400, error: oError, message: "Failed to login. Please try again." });
    }
});