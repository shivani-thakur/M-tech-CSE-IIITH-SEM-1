import React, {useState} from 'react'
import "./Login.css"

export const Login = (attributes) => {
    const [name, setName] = useState("");
    const [password, setPass] = useState("");

    const onSumbitPress = async (e) => {
        e.preventDefault();
        try {
            var response = await fetch("http://localhost:5000/login", {
                method: "POST",
                body: JSON.stringify({
                    name: name,
                    password: password
                }),
                headers: new Headers({'content-type': 'application/json'}),
            });
            var jsonResponse = await response.json();
            if (jsonResponse.status === 200) {
                setName("");
                setPass("");
                attributes.onSwitchPage("todo");
                window.localStorage.setItem("token", jsonResponse.data.token);
                window.localStorage.setItem("isAdmin", jsonResponse.data.isAdmin);
            } else {
                alert("Invalid credentials. Please try again.");
            }
        } catch (error) {
            alert("Login failed. Please try again.");
            console.log(error);
        }
    }

    return (
        <div className="formContainer">
            <form onSubmit={onSumbitPress} method="post">
                <div className="loginForm">
                    <h2>Login</h2>
                    <label htmlFor="uname"><b>Username</b></label>
                    <br/>
                    <input value={name} className='formInputFields' onChange={(e) => setName(e.target.value)} type="text" placeholder="Enter username" name="uname" required />
                    <br/>

                    <br/>
                    <label htmlFor="password"><b>Password</b></label>
                    <br/>
                    <input value={password} className='formInputFields' onChange={(e) => setPass(e.target.value)} type="password" placeholder="Enter password" name="password" required />
                    <br/>
                    <br/>
                    <button type="submit" className="loginSubmitButton">Login</button>
                    <p> New user?{' '}
                        <span className="signupLink" onClick={() => attributes.onSwitchPage("signup")}>
                        Create account
                        </span>
                    </p>
                </div>
            </form>
        </div>
    )
}