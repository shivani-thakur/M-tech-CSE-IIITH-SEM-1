import React, {useState} from 'react'
import "./Signup.css"

export const Signup = (attributes) => {
    const [uname, setUName] = useState("");
    const [password, setPass] = useState("");
    const [confpassword, setConfPass] = useState("");

    const onSumbitPress = async (e) => {
        e.preventDefault();
        try {
            var response = await fetch("http://localhost:5000/signup", {
                method: "POST",
                body: JSON.stringify({
                    name: uname,
                    password: password
                }),
                headers: new Headers({'content-type': 'application/json'}),
            });
            var jsonResponse = await response.json();
            if (jsonResponse.status === 200) {
                setUName("");
                setPass("");
                setConfPass("");
                alert("Signup successful. Please login now.");
            } else {
                alert("Signup failed. Please try again.");
            }
        } catch (error) {
            alert("Signup failed. Please try again.");
            console.log(error);
        }
    }

    const onConfirmPass = async (e) => {
        if (password === confpassword) {
            setConfPass(confpassword);
        }
        else {
            alert("Passwords doesn't match");
            setConfPass("");
        }
    }

    return (
        <div className="formContainer">
            <form onSubmit={onSumbitPress} method="post">
                <div className="loginForm">
                    <h2>Signup</h2>

                    <label htmlFor="emailid"><b>Username</b></label>
                    <br/>
                    <input className='formInputFields' value={uname} onChange={(e) => setUName(e.target.value)} type="text" placeholder="Enter username" name="emailid" required />
                    <br/>

                    <br/>
                    <label htmlFor="password"><b>Password</b></label>
                    <br/>
                    <input className='formInputFields' value={password} onChange={(e) => setPass(e.target.value)} type="password" placeholder="Enter password" name="password" required />
                    <br/>

                    <br/>
                    <label htmlFor="confpassword"><b>Confirm Password</b></label>
                    <br/>
                    <input className='formInputFields' value={confpassword} onChange={(e) => setConfPass(e.target.value)} onBlur={onConfirmPass} type="password" placeholder="Type password again" name="confpassword" required />
                    <br/>

                    <br/>
                    <button type="submit" className="signupSubmitButton">Signup</button>
                    <p> Existing user?{' '}
                        <span className="signinLink" onClick={() => attributes.onSwitchPage("login")}>
                        Back to login
                        </span>
                    </p>
                </div>
            </form>
        </div>
    )
}
