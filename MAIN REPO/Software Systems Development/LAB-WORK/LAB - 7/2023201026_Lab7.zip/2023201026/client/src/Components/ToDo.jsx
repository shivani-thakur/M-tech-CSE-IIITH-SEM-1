import React, {useState} from 'react'
import "./ToDo.css"

export const ToDo = () => {
    const [title, setTitle] = useState("");
    const [description, setDesc] = useState("");
    const [date, setDate] = useState("");
    const onSumbitPress = (e) => {
        e.preventDefault();
        const str = `Title: ${title}\nDescription: ${description}\nDate: ${date}`;
        alert(str);
        setTitle("");
        setDesc("");
        setDate("");
    }
    const onValidateDate = async (e) => {
        const now = new Date();
        const selected = new Date(date);
        if (selected < now) {
            alert ("Date can't be from past");
            setDate("");
        }
    }
    return (
        <div className='todoListContainer'>
            <form onSubmit={onSumbitPress} method="post">
                <h2>To-do list</h2>
                <label htmlFor="title"><b>Title</b></label>
                <br/>
                <input value={title} className='formInputFields' onChange={(e) => setTitle(e.target.value)} type="text" placeholder="Enter title" name="title" required />
                <br/>
                <br/>
                <label htmlFor="desc"><b>Title</b></label>
                <br/>
                <textarea value={description} className='todoDesc' onChange={(e) => setDesc(e.target.value)} type="text" placeholder="Enter description" name="desc" required />
                <br/>
                <br/>
                <label htmlFor="date"><b>Select Date</b></label>
                <br/>
                <input value={date} onChange={(e) => setDate(e.target.value)} onBlur={onValidateDate} type="date" name="date"></input>
                <br/>
                <br/>
                <button type="submit" className="loginSubmitButton">Submit</button>
            </form>
        </div>
    )
}
