import './App.css';
import React, {useState} from 'react'
import { Login } from './Components/Login';
import { Signup } from './Components/Signup';
import { ToDo } from './Components/ToDo';

function App() {
  const [currentPage, setCurrentPage] = useState("login");
  const togglePageState = (currPageName) => {
    setCurrentPage(currPageName);
  }
  var divContainer = <Login onSwitchPage={togglePageState}/>;
  if (currentPage === "login") {
    divContainer = <Login onSwitchPage={togglePageState}/>
  } else if (currentPage === "signup") {
    divContainer = <Signup onSwitchPage={togglePageState}/>
  } else if (currentPage === "todo") {
    divContainer = <ToDo onSwitchPage={togglePageState}/>
  }
  return (
    <div>
      {divContainer}
    </div>
  );
}

export default App;
