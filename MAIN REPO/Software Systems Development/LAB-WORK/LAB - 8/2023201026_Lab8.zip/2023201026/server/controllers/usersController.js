
const mongoose = require('mongoose')
const bcrypt = require("bcryptjs");
const User = require("../models/usersModel")

// login api
const loginUser = async (req, res) => {
    console.log(req.body);

    const { name, password } = req.body
    if (!name || !password) {
        res.status(404).json({ msg: 'missing details' })
    }

    const user = await User.findOne({ name: name })

    if (!user) {
        return res.status(404).json({ msg: "User doesn't exists" })
    }

    const matchingPassword = await bcrypt.compare(password, user.password)

    if (matchingPassword) {
        const userSession = { id: user._id }
        console.log(req);
        res.status(200).json({ msg: 'login successful', userSession })
    } else {
        res.status(404).json({ msg: 'Invalid credentials' })
    }
}


// signup api
const signupUser = async (req, res) => {
    const {name, password} = req.body;
    try {
        console.log(req.body)
        if (!name || !password)
            return res.status(404).json({ msg: 'Missing details' })

        const user = await User.findOne({ name: name })
        if (user) return res.status(404).json({ msg: 'existing user, please login.' })

        const hashedPassword = await bcrypt.hash(password, 10);

        await User.create({
            name: name,
            password: hashedPassword
        });
        return res.status(200).json({ msg: 'user created successfully' })
    } catch (error) {
        console.log(error)
        return res.status(404).json({ msg: 'signup failed, try again later.' })
    }
}
module.exports = {
    loginUser,
    signupUser
}