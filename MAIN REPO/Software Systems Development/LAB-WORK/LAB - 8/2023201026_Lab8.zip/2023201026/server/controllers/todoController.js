const mongoose = require('mongoose')
const ToDo = require("../models/toDoModel")

const createToDoItem = async (req, res) => {
    const {title, description, dueDate, status} = req.body;

    try {
        console.log(req.body)
        if (!title || !description || !dueDate || !status)
            return res.status(404).json({ msg: 'Missing details' })

        await ToDo.create({
            title, description, dueDate, status
        });
        return res.status(200).json({ msg: 'To-do item created successfully', status: 200 })
    } catch (error) {
        console.log(error)
        return res.status(404).json({ msg: 'To-do item creation failed, try again later.' })
    }
}

const completedTodoItem = async (req, res) => {
    const completedToDos = await ToDo.find({status: false}).sort({
        dueDate: -1
    });

    res.status(200).json(completedToDos);
}

const pendingTodoItem = async (req, res) => {
    const pendingToDos = await ToDo.find({status: true}).sort({
        dueDate: -1
    });

    res.status(200).json(pendingToDos);
}

module.exports = {
    createToDoItem,
    completedTodoItem,
    pendingTodoItem
}