const mongoose = require("mongoose");

// specify schema
const UserDetailsSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            unique: true
        },
        password: {
            type: String,
            required: true,
        }
    },
    {
        collection: "User"
    }
);

// update data into the table
module.exports = mongoose.model("User", UserDetailsSchema);