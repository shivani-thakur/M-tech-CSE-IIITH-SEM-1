const mongoose = require("mongoose");

// specify schema
const ToDoSchema = new mongoose.Schema(
    {
        title: {
            type: String,
            required: true
        },
        description: {
            type: String,
            required: true,
        },
        dueDate: {
            type: Date,
            required: true,
        },
        status: {
            type: Boolean,
            required: true,
        }
    },
    {
        collection: "ToDo"
    }
);

// update data into the table
module.exports = mongoose.model("ToDo", ToDoSchema);