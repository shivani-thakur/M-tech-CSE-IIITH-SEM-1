const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const userRoutes = require("./routes/users");
const toDoRoutes = require("./routes/toDo");

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/users", userRoutes);
app.use("/api/todo", toDoRoutes);

mongoose.connect(process.env.MONGO_URI)
    .then(() => {
        console.log("connected to db");
        app.listen(process.env.PORT, () => {
            console.log("listening on port 8080");
        });
    })
    .catch((error) => {
        console.log(error);
    })
