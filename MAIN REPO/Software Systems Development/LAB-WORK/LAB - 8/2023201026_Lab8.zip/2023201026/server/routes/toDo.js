const express = require('express');
const {
    createToDoItem,
    completedTodoItem,
    pendingTodoItem
} = require("../controllers/todoController")

const router = express.Router();

router.post("/createtodo", createToDoItem);
router.get("/getCompletedTodo", completedTodoItem);
router.get("/getPendingTodo", pendingTodoItem);

module.exports = router;