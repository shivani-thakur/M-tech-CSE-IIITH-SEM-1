# DB:
create a DB named 'Lab8Mern' using mongodb compass.
Make sure to connect to the db before going to further steps.

# BE:
All the APIs are developed required for this functionality. APIs can be tested either through postman or thuderclient

1. to get pending todos send GET request to:
http://localhost:8080/api/todo/getPendingTodo

2. to get completed todos send GET request to:
http://localhost:8080/api/todo/getCompletedTodo

3. to create a todo item send POST request to:
http://localhost:8080/api/todo/createtodo
payload sample:
{
  "title" : "to-do item2",
  "description": "to-do item2",
  "dueDate": "2023-03-29T13:34:00.000",
  "status": "1"
}
* make sure to pass Content-Type: application/json in the request headers

4. to create a user send a POST request to:
http://localhost:8080/api/users/signup
payload sample:
{
  "name": "abc",
  "password": "abc"
}
* make sure to pass Content-Type: application/json in the request headers

5. to login as a user send a POST request to:
http://localhost:8080/api/users/login
payload sample:
{
  "name": "abc",
  "password": "abc"
}
* make sure to pass Content-Type: application/json in the request headers

# UI:
UI contains a single page to create a to-do list.
User can't enter a past date.
When clicked on submit, backend will be called and data will be stored in the DB.
As mentioned above, all the reuqired BE APIs are ready and can be tested using postman/thunderclient

## To Run BE:
- go to server folder
- run command 'npm install'
- to start app, run command 'npm run nodemon'

To Run UI:
- go to client folder
- run command 'npm install'
- to start app, run command 'npm start'