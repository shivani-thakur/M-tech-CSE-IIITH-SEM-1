import React, {useState} from 'react'

export const CreateTodo = () => {
    const [title, setTitle] = useState("");
    const [description, setDesc] = useState("");
    const [date, setDate] = useState("");
    const onSumbitPress = async (e) => {
        e.preventDefault();
        try {
            var response = await fetch("http://localhost:8080/api/todo/createtodo", {
                method: "POST",
                body: JSON.stringify({
                    title : title,
                    description: description,
                    dueDate: date,
                    status: "1"
                }),
                headers: new Headers({'content-type': 'application/json'}),
            });
            var jsonResponse = await response.json();
            if (jsonResponse.status === 200) {
                alert("Created Successfully");
                setTitle("");
                setDesc("");
                setDate("");
            } else {
                alert("Failed. Please try again.");
            }
        } catch (error) {
            alert("Failed. Please try again.");
            console.log(error);
        }
    }
    const onValidateDate = async (e) => {
        const now = new Date();
        const selected = new Date(date);
        if (selected < now) {
            alert ("Date can't be from past");
            setDate("");
        }
    }

  return (
    <div className='todoListContainer'>
        <form onSubmit={onSumbitPress} method="post">
            <h2>To-do list</h2>
            <label htmlFor="title"><b>Title</b></label>
            <br/>
            <input value={title} className='formInputFields' onChange={(e) => setTitle(e.target.value)} type="text" placeholder="Enter title" name="title" required />
            <br/>
            <br/>
            <label htmlFor="desc"><b>Description</b></label>
            <br/>
            <textarea value={description} className='todoDesc' onChange={(e) => setDesc(e.target.value)} type="text" placeholder="Enter description" name="desc" required />
            <br/>
            <br/>
            <label htmlFor="date"><b>Select Date</b></label>
            <br/>
            <input value={date} onChange={(e) => setDate(e.target.value)} onBlur={onValidateDate} type="date" name="date"></input>
            <br/>
            <br/>
            <button type="submit" className="loginSubmitButton">Submit</button>
        </form>
    </div>
  )
}

export default CreateTodo
