from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.dialects.mysql import JSON
from sqlalchemy.exc import SQLAlchemyError

# Initialize flask app
app = Flask(__name__)

# add your own MySQL connection String
# mysql://username:password@ip:port/db_name
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:root@localhost:3306/lab11'

# Connect SQLAlchemy engine to db and create db object
db = SQLAlchemy(app)

# Enable Cross-Origin Resource Sharing (CORS)
CORS(app)

# Define the Menu Entity
class Menu(db.Model):
    __table_args__ = {'schema': 'lab11', 'extend_existing': True}
    __tablename__ = 'Menu'  # Set the explicit table name

    item_id = db.Column(db.Integer, nullable=False, primary_key=True)
    item_name = db.Column(db.String(80), nullable=False)
    item_price = db.Column(db.Integer, nullable=False)

    def __init__(self, item_id, item_name, item_price):
        self.item_id = item_id
        self.item_name = item_name
        self.item_price = item_price

    def __repr__(self):
        return f'<Item {self.item_name}>'

    def to_dict(self):
        return {
            'id': self.item_id,
            'Item': self.item_name,
            'Price': self.item_price
        }
    
# Define the CustomerOrder Entity
class CustomerOrder(db.Model):
    __table_args__ = {'schema': 'lab11', 'extend_existing': True}
    __tablename__ = 'CustomerOrder'  # Set the explicit table name

    customer_id = db.Column(db.Integer, nullable=False, primary_key=True)
    items = db.Column(JSON(db.Integer), nullable=True)

    def __init__(self, customer_id):
        self.customer_id = customer_id

    def to_dict(self):
        return {
            'customer_id': self.customer_id
        }

def api_error_response():
    return jsonify({"error": "There is some issue. Please try again"}), 418

@app.route('/admin/menu', methods=['GET', 'POST', 'PUT'])
def view_menu_list():
    if request.method == 'GET':
        try:
            headers = request.headers
            if headers.get('rootOrg') != 'Restuarant' or headers.get('org') != 'Shaandar':
                return api_error_response()

            menu_items = Menu.query.all()
            menu_list = [{"item_id": item.item_id, "item_name": item.item_name, "item_price": item.item_price} for item in menu_items]

            return jsonify(menu_list), 200
        except SQLAlchemyError as e:
            db.session.rollback() 
            return api_error_response()
        except Exception as e:
            return api_error_response()

    elif request.method == 'POST':
        try:
            headers = request.headers
            if headers.get('rootOrg') != 'Restuarant' or headers.get('org') != 'Shaandar':
                return api_error_response()

            data = request.get_json()
            if not all(key in data for key in ['item_id', 'item_name', 'item_price']):
                return api_error_response()
            if not data['item_name']:
                return api_error_response()

            new_item = Menu(item_id=data['item_id'], item_name=data['item_name'], item_price=data['item_price'])
            db.session.add(new_item)
            db.session.commit()

            return jsonify({"message": "Item added successfully."}), 200
        except SQLAlchemyError as e:
            db.session.rollback() 
            return api_error_response()
        except Exception as e:
            return api_error_response()
    
    elif request.method == 'PUT':
        try:
            headers = request.headers
            if headers.get('rootOrg') != 'Restuarant' or headers.get('org') != 'Shaandar':
                return api_error_response()

            data = request.get_json()
            if not all(key in data for key in ['item_id', 'item_name', 'item_price']):
                return api_error_response()
            if not data['item_name']:
                return api_error_response()

            item_id = data['item_id']
            existing_item = Menu.query.get(item_id)
            if existing_item:
                existing_item.item_name = data['item_name']
                existing_item.item_price = data['item_price']
                db.session.commit()
                return jsonify({"message": "Item updated successfully."}), 200
            else:
                return api_error_response()

        except SQLAlchemyError as e:
            db.session.rollback()
            return api_error_response()
        except Exception as e:
            return api_error_response()
        
@app.route('/staff/bill', methods=['GET'])
def view_customer_order_and_bill():
    try:
        headers = request.headers
        if headers.get('rootOrg') != 'Restuarant' or headers.get('org') != 'Shaandar':
            return api_error_response()

        customer_id = request.args.get('customer_id')

        if not customer_id:
            return api_error_response()

        customer_order = CustomerOrder.query.filter_by(customer_id=customer_id).first()
        if customer_order:
            bill_amount = 0
            items_list = []

            for item_id in customer_order.items:
                menu_item = Menu.query.get(item_id)
                if menu_item:
                    items_list.append({
                        "item_id": menu_item.item_id,
                        "item_name": menu_item.item_name,
                        "item_price": menu_item.item_price
                    })
                    bill_amount += menu_item.item_price

            response_data = {
                "customer_id": customer_id,
                "bill_amount": bill_amount,
                "items": items_list
            }
            return jsonify(response_data), 200
        else:
            return api_error_response()

    except SQLAlchemyError as e:
        db.session.rollback()  # Rollback the transaction in case of a database error
        return api_error_response()
    except Exception as e:
        return api_error_response()

@app.route('/staff/orders', methods=['GET'])
def view_customer_orders():
    try:
        # Validate headers
        headers = request.headers
        if headers.get('rootOrg') != 'Restuarant' or headers.get('org') != 'Shaandar':
            return api_error_response()

        # Retrieve and return the customer orders
        customer_orders = CustomerOrder.query.all()
        orders_list = []

        for order in customer_orders:
            customer_order = {
                "customer_id": order.customer_id,
                "items": []
            }
            
            for item_id in order.items:
                menu_item = Menu.query.get(item_id)
                if menu_item:
                    customer_order["items"].append({
                        "item_id": menu_item.item_id,
                        "item_name": menu_item.item_name,
                        "item_price": menu_item.item_price
                    })
            
            orders_list.append(customer_order)

        return jsonify(orders_list), 200
    except SQLAlchemyError as e:
        db.session.rollback()  # Rollback the transaction in case of a database error
        return api_error_response()
    except Exception as e:
        return api_error_response()


@app.route('/customer/order', methods=['GET'])
def view_current_order():
    try:
        headers = request.headers
        if headers.get('rootOrg') != 'Restuarant' or headers.get('org') != 'Shaandar':
            return api_error_response()
        customer_id = headers.get("customer_id")
        if not customer_id:
            return api_error_response()

        existing_customer = CustomerOrder.query.filter_by(customer_id=customer_id).first()

        if not existing_customer:
            return api_error_response()

        current_order = existing_customer.items if existing_customer.items else []

        response_data = []

        for item in current_order:
            response_data.append({
                "item_id": item.get("item_id"),
                "item_name": item.get("item_name"),
                "price": item.get("price")
            })

        return jsonify(response_data), 200

    except Exception as e:
        return api_error_response()
    
@app.route('/customer/order/add', methods=['POST'])
def add_item_to_order():
    try:
        headers = request.headers
        if headers.get('rootOrg') != 'Restuarant' or headers.get('org') != 'Shaandar':
            return api_error_response()
        customer_id = headers.get("customer_id")
        if not customer_id:
            return api_error_response()

        existing_customer = CustomerOrder.query.filter_by(customer_id=customer_id).first()

        if not existing_customer:
            return api_error_response()

        data = request.get_json()
        if not data or "item_id" not in data or "item_name" not in data:
            return api_error_response()

        current_order = existing_customer.items if existing_customer.items else []

        new_item = {
            "item_id": data["item_id"],
            "item_name": data["item_name"]
        }
        current_order.append(new_item)

        existing_customer.items = current_order

        db.session.commit()

        return jsonify({"message": "Item added to the order successfully."}), 200

    except Exception as e:
        return api_error_response()
    
@app.route('/customer/bill', methods=['GET'])
def render_bill():
    try:
        headers = request.headers
        if headers.get('rootOrg') != 'Restuarant' or headers.get('org') != 'Shaandar':
            return api_error_response()
        customer_id = headers.get("customer_id")
        if not customer_id:
            return api_error_response()

        existing_customer = CustomerOrder.query.filter_by(customer_id=customer_id).first()

        if not existing_customer:
            return api_error_response()

        current_order = existing_customer.items if existing_customer.items else []

        total_amount = sum(item.get("price", 0) for item in current_order)

        return render_template('bill.html', customer_id=customer_id, current_order=current_order, total_amount=total_amount)

    except Exception as e:
        return api_error_response()

@app.route('/customer/order/remove/<int:item_id>', methods=['DELETE'])
def remove_item_from_order(item_id):
    try:
        headers = request.headers
        if headers.get('rootOrg') != 'Restuarant' or headers.get('org') != 'Shaandar':
            return api_error_response()
        customer_id = headers.get("customer_id")
        if not customer_id:
            return api_error_response()

        existing_customer = CustomerOrder.query.filter_by(customer_id=customer_id).first()

        if not existing_customer:
            return api_error_response()

        current_order = existing_customer.items if existing_customer.items else []

        item_to_remove = None
        for item in current_order:
            if item.get("item_id") == item_id:
                item_to_remove = item
                break

        if not item_to_remove:
            return api_error_response()

        current_order.remove(item_to_remove)

        existing_customer.items = current_order

        db.session.commit()

        return jsonify({"message": "Item removed from the order successfully."}), 200

    except Exception as e:
        return api_error_response()

if __name__ == '__main__':
    app.run(debug=True)