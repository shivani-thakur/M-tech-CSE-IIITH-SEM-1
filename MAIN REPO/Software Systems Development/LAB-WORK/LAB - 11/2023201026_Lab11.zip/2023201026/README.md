# Restaurant Management API
Command to run:
```
python3 ./2023201026_main.py
```