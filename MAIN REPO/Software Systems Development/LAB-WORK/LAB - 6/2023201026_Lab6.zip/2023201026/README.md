1. Input form for collecting data for gali cricket team.
