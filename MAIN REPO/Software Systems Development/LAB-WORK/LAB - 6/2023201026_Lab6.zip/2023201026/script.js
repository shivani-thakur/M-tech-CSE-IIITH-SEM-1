function validateFormOnSubmit (oFormObject) {
    if (validateName() && validatePass()) {
        var sTeamName = document.forms["galiCricketData"]["teamname"].value;
        var sCoachName = document.forms["galiCricketData"]["coachname"].value;
        var sTeamEmail = document.forms["galiCricketData"]["emailid"].value;
        var sTeamMembers = document.forms["galiCricketData"]["teammem"].value;
        var temaCap = document.getElementById("captain");
        var capName = temaCap.options[temaCap.selectedIndex].text;

        var finalStr = `Team Name: ${sTeamName}\nTeam Email id: ${sTeamEmail}\nTeam Coach Name: ${sCoachName}\nTeam Captain: ${capName}\nTeam Members: ${sTeamMembers}\n`;
        alert(finalStr);
    }
    else {
        return false;
    }
}

function validateTeamName () {
    var sTeamName = document.forms["galiCricketData"]["teamname"].value;
    var pattern=/(?=.*\d)(?=.*[A-Z]).*/;
    if (!pattern.test(sTeamName)) {
        document.getElementById('errorname').innerHTML = "Invalid team name";
    } else {
        document.getElementById('errorname').innerHTML = "";
    }
}

function onShowPassword () {
    var passField = document.getElementById("password");
    if (passField.type === "password") {
        passField.type = "text";
    } else {
        passField.type = "password";
    }
}

function validatePass () {
    var oldPass = document.forms["galiCricketData"]["password"].value;
    var newPass = document.forms["galiCricketData"]["confirmpassword"].value;

    if (oldPass != newPass) {
        document.getElementById('errorpassword').innerHTML = "Password mismatch";
        return false;
    } else {
        document.getElementById('errorpassword').innerHTML = "";
        return true;
    }
}

function validateName () {
    var sTeamName = document.forms["galiCricketData"]["teamname"].value;
    var pattern=/(?=.*\d)(?=.*[A-Z]).*/;
    if (!pattern.test(sTeamName)) {
        document.getElementById('errorname').innerHTML = "Invalid team name";
        return false;
    } else {
        document.getElementById('errorname').innerHTML = "";
        return true;
    }
}

function onShowPassword2 () {
    var passField = document.getElementById("confirmpassword");
    if (passField.type === "password") {
        passField.type = "text";
    } else {
        passField.type = "password";
    }
}

function onConfirmPassChange () {
    var oldPass = document.forms["galiCricketData"]["password"].value;
    var newPass = document.forms["galiCricketData"]["confirmpassword"].value;

    if (oldPass != newPass) {
        document.getElementById('errorpassword').innerHTML = "Password mismatch";
    } else {
        document.getElementById('errorpassword').innerHTML = "";
    }
}

function onChangeMembers () {
    var teamMems = document.forms["galiCricketData"]["teammem"].value;
    const aTeamMembers = teamMems.split(',');

    var selectOptions = document.getElementById('captain');
    aTeamMembers.map( (member, index) => {
        var singleOption = document.createElement("option");
        singleOption.value = index;
        singleOption.innerHTML = member;
        selectOptions.append(singleOption);
    });
}

document.addEventListener('keydown', function(event) {
    if (event.ctrlKey && event.key === 'm') {
        document.body.classList.toggle('dark-mode');
    }
});