# Lab Activity 4
## Question 1
### Overview
1. Design login page.
2. It will have 2 input fields - name and password. And one button - Log in. 
3. Reset button is additionally added that will clear the login form fields.
4. Input fields have placeholder added. Buttons and input fields have hover effect.
5. Entering input is mandatory to login. When clicked on log in button, user will be navigated to next page.
6. On 2nd page, information about a movie will be shown.


## Question 2
### Overview
1. CSS properties like color gradient, hover, font family has been added.
### Assumption
1. Background color added to the entire body tag.