import pandas as pd
import random
from tabulate import tabulate

df = pd.read_csv("stock_data.csv")

def fnSearchStockBySymbol(input_symbol):
    results = []
    input_symbol = input_symbol.lower()
    for index, row in df.iterrows():
        if row['Symbol'].lower().startswith(input_symbol):
            results.append((row['Symbol'], row['LTP']))
    return results

# Question 1.1
df = df.iloc[:, :-6]
Q1_1TxtPath = r'Q1_1.txt'
with open(Q1_1TxtPath, 'w') as file:
    dataString = df.to_string(header=True, index=False)
    file.write(dataString)

# Question 1.2
filtered_rows = filter(lambda x: x[6] >= -3, df.values)
df = pd.DataFrame(filtered_rows, columns=df.columns)
Q1_2TxtPath = r'Q1_2.txt'
with open(Q1_2TxtPath, 'w') as file:
    dataString = df.to_string(header=True, index=False)
    file.write(dataString)

# Question 1.3
openData = df['Open'].map(lambda x: float(x.replace(',', '')))
highData = df['High'].map(lambda x: float(x.replace(',', '')))
lowData = df['Low'].map(lambda x: float(x.replace(',', '')))
averageOfOpen = round(openData.mean(), 3)
averageOfHigh = round(highData.mean(), 3)
averageOfLow = round(lowData.mean(), 3)
with open('Q1_3.txt', 'w') as output_file:
    output_file.write(f"Average of open: {averageOfOpen}\n")
    output_file.write(f"Average of high: {averageOfHigh}\n")
    output_file.write(f"Average of low: {averageOfLow}\n")

# Question 1.4
inputChar = input("Enter a character (A-Z or a-z): ")
if len(inputChar) == 1 and inputChar.isalpha():
    results = fnSearchStockBySymbol(inputChar)
    headers = ["Symbol", "LTP"]
    print(tabulate(results, headers, tablefmt="grid"))
    with open('Q1_4.txt', 'w') as file:
        file.write(tabulate(results, headers, tablefmt="grid"))
else:
    print("Invalid input. Please enter a single character (A-Z or a-z).")

# Question 1.5
possible_class = ['A', 'B', 'C', 'D', 'E', 'F']
possible_ages = range(21, 56)
possible_status = [True, False]
fclass = []
fage= []
fstatus = []
fsalary = []
for num in range(10):
    sclass = random.choice(possible_class)
    age = random.choice(possible_ages)
    status = random.choice(possible_status)
    salary = round(random.uniform(10000.00, 50000.00), 2)
    fclass.append(sclass)
    fage.append(age)
    fstatus.append(status)
    fsalary.append(salary)
data = pd.DataFrame({"Salary": fsalary,
                   "Age":fage,
                   "Class": fclass,
                   "Status": fstatus})
with open('Q1_5.txt', 'w') as file:
    dataString = data.to_string(header=True, index=False)
    file.write(dataString)
    
