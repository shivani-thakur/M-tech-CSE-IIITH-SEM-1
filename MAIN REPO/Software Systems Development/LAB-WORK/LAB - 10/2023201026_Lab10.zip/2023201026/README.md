# Data Processing and Generation Project

This project performs various data processing tasks and generates a random dataset. It is implemented in Python and consists of multiple parts, each addressing a specific task.

## Prerequisites

- Python 3.x
- Pandas library (for data manipulation)
- Random library (for generating random data)
- Tabulate library (for printing table)

## Parts of the Project

### Question 1.1

**Task:** Read a CSV file, drop the last 6 columns, and write the resulting dataset to a file named "Q1_1.txt".

### Question 1.2

**Task:** Drop rows with a percentage change less than -3%, using filter and lambda functions. Write the resulting dataset to "Q1_2.txt".

### Question 1.3

**Task:** Calculate the average of Open, High, and Low using map and lambda functions. Write the results to "Q1_3.txt".

### Question 1.4

**Task:** Display the <Symbol, LTP> of stocks whose symbol starts with a user-input character. Results are displayed in the terminal and saved in "Q1_4.txt".

### Question 1.5

**Task:** Generate a random dataset with columns Salary, Age, Class, and Status. The dataset is saved in "Q1_5.txt".

## How to Use

1. Place your input CSV file in the same directory as the Python script and update the file name accordingly in the script (Question 1.1).
i.e. There must be a file stock_data.csv in 2023201026 folder along with python script

2. Run the Python script to execute the tasks for Questions 1.1 to 1.5.

3. For Question 1.4, you will be prompted to enter a character (A-Z or a-z). The script will display and save the results for stocks whose symbol starts with that character.

4. The results for each question will be saved in separate output files: Q1_1.txt, Q1_2.txt, Q1_3.txt, Q1_4.txt, and Q1_5.txt.

5. The random dataset for Question 1.5 will contain 10 rows with the specified columns: Salary, Age, Class, and Status.

6. Review the output files for the respective results.

